var stuckTimeout
stuckTimeout = setTimeout(function(){
	document.getElementById("stuck").style.display="block"
},5000)